set terminal pdfcairo enhanced color font "Verdana,10" size 4,3
set output "hit_and_miss_error.pdf"
set key right top opaque

set grid
set logscale x
set logscale y

set title "Hit-and-Miss Integration Error vs. Number of Trials"
set xlabel "Number of Trials (N)"
set ylabel "Absolute Error"


plot "hit_miss_data.txt" using 1:2 with linespoints title "f_1(x) = x^2 + x + 1", \
     "hit_miss_data.txt" using 1:3 with linespoints title "f_2(x) = sqrt(1-x^2)", \
     "hit_miss_data.txt" using 1:4 with linespoints title "f_3(x) = 1/sqrt(x)"
